#!/bin/bash
set -e

# Create directories
mkdir -p ~/.local/bin
mkdir -p ~/.local/lib/logmanticsai
mkdir -p ~/.config/logmanticsai/results

# Copy files
cp -r lib/logmanticsai/* ~/.local/lib/logmanticsai/
cp bin/* ~/.local/bin/

# Make binaries executable
chmod 755 ~/.local/bin/logmanticsai-*

echo "LogManticsAI installed to ~/.local/bin"
echo "Add this directory to your PATH if not already added:"
echo "export PATH=\$PATH:~/.local/bin"

